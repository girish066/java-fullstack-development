package com.practice;

import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("enter the string");
		String s=sc.nextLine();
		System.out.println(s.length());
		int len=s.length();
		s=s.toUpperCase();
		String s2=new String();
		for(int i=len-1;i>=0;i--)
		{
			s2=s2+s.charAt(i);
		}
		System.out.println("original string is " +s);
		System.out.println("reversed string is " +s2);
		
		if (s.equals(s2))
		{
			System.out.println("palindrome");
		}
		else {
			System.out.println("non palindrome");
		}
	}

}
