package com.practice;

import java.util.Scanner;

public class Commandline {
	public static void main(String[] args) {
		int  n=15 ,num1,num2;
		System.out.println("given the value of num1");
		System.out.println("give the value of num2");
		Scanner sc =new Scanner(System.in);
		num1=sc.nextInt();
		num2=sc.nextInt();
		System.out.println("series "+n+"numbers:");
		for (int i=1;i<=n;i++)
		{
			System.out.println(num1+" ");
			int Sumofprevtwo =num1+num2;
			num1=num2;
			num2=Sumofprevtwo;
		}
		

	}
}
